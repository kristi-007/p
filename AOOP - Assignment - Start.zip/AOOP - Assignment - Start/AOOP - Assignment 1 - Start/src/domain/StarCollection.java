package domain;

public class StarCollection {

}
